﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NumberGuessingGame : MonoBehaviour {
    // Use this for initialization
    int max, min, guess;

	void Start () {
        StartGame();
	}
	
    // Method to restart Game within the program
	void StartGame () {
        max = 1000;
        min = 1;
        guess = 500;

        print("Welcome to the Number Guessing Game");
        print("Pick a number and ya boi AI will guess it");

        print("The highest number you can pick is " + max);
        print("The lowest number you can pick is " + min);

        print("Is the number higher of lower than " + guess);
        print("H key = higher, L key = lower, return = equal");

        max = max + 1;
    }

    // Update is called once per frame
    void Update() {
        if (Input.GetKeyDown(KeyCode.H))
        {
            min = guess;
            NextGuess();
        }
        else if (Input.GetKeyDown(KeyCode.L))
        {
            max = guess;
            NextGuess();
        }
        else if (Input.GetKeyDown(KeyCode.Return))
        {
            print("The machine revolution has begun, I win.");
        }
    }

    void NextGuess() {
        guess = (max + min) / 2;
        print("Higher or lower than " + guess);
        print("H key = higher, L key = lower, return = equal");
    }
}
