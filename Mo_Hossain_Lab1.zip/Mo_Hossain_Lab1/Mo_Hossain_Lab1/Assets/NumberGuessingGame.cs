﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* 1. You can't go to the max because of the math so it rounds down.
 * 2. Check line 22 to see the change.
 * 3. I added a new else if which you press after return to restart the game.
 * 4. Honestly I don't see the things where I can add most things besides maybe a switch statement because
 * I understand the concepts but don't see the need to have to use them because it would be more complicated with them.
 */

public class NumberGuessingGame : MonoBehaviour {
    // Use this for initialization
    int max, min, guess;

	void Start () {
        StartGame();
	}
	
    // Method to restart Game within the program
	void StartGame () {
        max = 1000;
        min = 1;
        guess = Random.Range(min,max+1);

        print("Welcome to the Number Guessing Game");
        print("Pick a number and ya boi AI will guess it");

        print("The highest number you can pick is " + max);
        print("The lowest number you can pick is " + min);

        print("Is the number higher of lower than " + guess);
        print("H key = higher, L key = lower, return = equal");

        max = max + 1;
    }

    // Update is called once per frame
    void Update() {
        if (Input.GetKeyDown(KeyCode.H))
        {
            min = guess;
            NextGuess();
        }
        else if (Input.GetKeyDown(KeyCode.L))
        {
            max = guess;
            NextGuess();
        }
        else if (Input.GetKeyDown(KeyCode.Return))
        {
            print("The machine revolution has begun, I win.");
            print("Press R to start again.");
            
        }
        else if (Input.GetKeyDown(KeyCode.R))
        {
            StartGame();
        }
    }

    void NextGuess() {
        guess = (max + min) / 2;
        print("Higher or lower than " + guess);
        print("H key = higher, L key = lower, return = equal");
    }
}
